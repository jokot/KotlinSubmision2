package com.example.jokot.footballclub.model

data class TeamResponse(var teams: List<Team>)